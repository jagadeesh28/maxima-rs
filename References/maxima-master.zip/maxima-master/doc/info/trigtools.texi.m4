@c -*- mode: texinfo -*-

@menu
* Introduction to trigtools::
* Functions and Variables for trigtools::
* References::
@end menu

@node Introduction to trigtools, Functions and Variables for trigtools, Package trigtools, Package trigtools
@center @titlefont{Trigtools Package}
@sp 2
@center @b{Aleksas Dormarkas}
@center @email{aleksasd873@@gmail.com}
@center @email{aleksas.domarkas@@mif.vu.lt}
@center December 1, 2013

@section Introduction to trigtools
We use open-source computer algebra system(CAS) maxima 5.31.2.
The trigtools package@footnote{This is a conversion by hand of the original ``trigtools-doc.pdf'' file in ``share/contrib/trigtools'', by Raymond Toy.  See the pdf for the definitive version.} contains commands that help you work with
trigonometric expressions. List of functions in trigtools package:

@itemize
@item @mref{c2sin}
@item @mref{c2cos}
@item @mref{c2trig}
@item @mref{c2hyp}
@item @mref{trigfactor}
@item @mref{trigsolve}
@item @mref{trigvalue}
@item @mref{trigeval}
@item @mref{atan_contract}
@end itemize

@opencatbox{Categories:}
@category{Trigonometric functions}
@category{Package trigtools}
@closecatbox

@node Functions and Variables for trigtools, References, Introduction to trigtools, Package trigtools
@section Functions and Variables for trigtools

@menu
* Convert to sin and cos::
* Convert to Trigonometric Functions::
* Convert to Hyperbolic Functions::
* Factor Sums of sin and cos Functions::
* Solve Trigonometric Equations::
* Evaluation of Trigonometric Functions::
* Contract atan Functions::
@end menu

@node Convert to sin and cos, Convert to Trigonometric Functions, Functions and Variables for trigtools, Functions and Variables for trigtools
@subsection Convert to sin and cos

@anchor{c2sin}
@deffn {Function} c2sin (@var{x})
@anchor{c2cos}
@deffnx {Function} c2cos (@var{x})
The function c2sin converts the expression 
m4_math(<<<a\cos x + b\sin x>>>, <<<@math{a*cos(x)+b*sin(x)}>>>) 
to
m4_mathdot(<<<r\sin(x+\phi)>>>, <<<@math{r*sin(x+phi)}>>>)

The function c2cos converts the expression 
m4_math(<<<a\cos x + b\sin x>>>, <<<@math{ a*cos(x)+b*sin(x)}>>>) 
to
m4_mathdot(<<<r\cos(x-\phi)>>>, <<<@math{r*cos(x-phi)}>>>)

@code{load("trigtools")} loads these functions.

Examples:
@c ===beg===
@c load("trigtools")$
@c c2sin(3*sin(x)+4*cos(x));
@c trigexpand(%),expand;
@c c2cos(3*sin(x)-4*cos(x));
@c trigexpand(%),expand;
@c c2sin(sin(x)+cos(x));
@c trigexpand(%),expand;
@c c2cos(sin(x)+cos(x));
@c trigexpand(%),expand;
@c ===end===
@example maxima
(%i1) load("trigtools")$
@group
(%i2) c2sin(3*sin(x)+4*cos(x));
                                      4
(%o2)                  5 sin(x + atan(-))
                                      3
@end group
@group
(%i3) trigexpand(%),expand;
(%o3)                  3 sin(x) + 4 cos(x)
@end group
@group
(%i4) c2cos(3*sin(x)-4*cos(x));
                                       3
(%o4)                 - 5 cos(x + atan(-))
                                       4
@end group
@group
(%i5) trigexpand(%),expand;
(%o5)                  3 sin(x) - 4 cos(x)
@end group
@group
(%i6) c2sin(sin(x)+cos(x));
                                      %pi
(%o6)                 sqrt(2) sin(x + ---)
                                       4
@end group
@group
(%i7) trigexpand(%),expand;
(%o7)                    sin(x) + cos(x)
@end group
@group
(%i8) c2cos(sin(x)+cos(x));
                                      %pi
(%o8)                 sqrt(2) cos(x - ---)
                                       4
@end group
@group
(%i9) trigexpand(%),expand;
(%o9)                    sin(x) + cos(x)
@end group
@end example

Example. Solve trigonometric equation

@c ===beg===
@c eq:3*sin(x)+4*cos(x)=2;
@c plot2d([3*sin(x)+4*cos(x),2],[x,-%pi,%pi]);
@c ===end===
@example maxima
@group
(%i1) eq:3*sin(x)+4*cos(x)=2;
(%o1)                3 sin(x) + 4 cos(x) = 2
@end group
@group
(%i2) plot2d([3*sin(x)+4*cos(x),2],[x,-%pi,%pi]);
(%o2)                         false
@end group
@end example

@center @image{figures/trigtools-1,5in,,plot1}

@c ===beg===
@c load("trigtools")$
@c eq:3*sin(x)+4*cos(x)=2$
@c eq1:c2sin(lhs(eq))=2;
@c solvetrigwarn:false$
@c solve(eq1)[1]$ x1:rhs(%);
@c float(%), numer;
@c eq2:c2cos(lhs(eq))=2;
@c solve(eq2,x)[1]$ x2:rhs(%);
@c float(%), numer;
@c sol:[x1,x2];
@c ===end===
@example maxima
(%i1) load("trigtools")$
(%i2) eq:3*sin(x)+4*cos(x)=2$
@group
(%i3) eq1:c2sin(lhs(eq))=2;
                                    4
(%o3)                5 sin(x + atan(-)) = 2
                                    3
@end group
(%i4) solvetrigwarn:false$
@group
(%i5) solve(eq1)[1]$ x1:rhs(%);
                             2         4
(%o6)                   asin(-) - atan(-)
                             5         3
@end group
@group
(%i7) float(%), numer;
(%o7)                 - 0.5157783719341241
@end group
@group
(%i8) eq2:c2cos(lhs(eq))=2;
                                    3
(%o8)                5 cos(x - atan(-)) = 2
                                    4
@end group
@group
(%i9) solve(eq2,x)[1]$ x2:rhs(%);
                             3         2
(%o10)                  atan(-) + acos(-)
                             4         5
@end group
@group
(%i11) float(%), numer;
(%o11)                  1.802780589520693
@end group
@group
(%i12) sol:[x1,x2];
                   2         4        3         2
(%o12)       [asin(-) - atan(-), atan(-) + acos(-)]
                   5         3        4         5
@end group
@end example


Answ.: 
m4_mathcomma(<<<x = x_1 + 2\pi k>>>,<<<x = x1 + 2*%pi*k>>>)
m4_mathcomma(<<<x_1 = \sin^{-1}{2\over 5} - \tan^{-1}{4\over
3}>>>, <<<x1 = asin(2/5)-atan(4/3)>>>)
or
m4_mathcomma(<<<x_1 = \tan^{-1}{3\over 4} + \cos^{-1}{2\over 5}>>>,
<<<x1 = atan(3/4)+acos(2/5)>>>)
for @math{k} any integer.

@opencatbox{Categories:}
@category{Trigonometric functions}
@category{Hyperbolic functions}
@category{Package trigtools}
@closecatbox
@end deffn

@node Convert to Trigonometric Functions, Convert to Hyperbolic Functions, Convert to sin and cos, Functions and Variables for trigtools
@subsection Convert to Trigonometric Functions

@anchor{c2trig}
@deffn {Function} c2trig (@var{x})
The function c2trig (convert to trigonometric) reduce expression with hyperbolic functions
sinh, cosh, tanh, coth to trigonometric expression with sin, cos, tan, cot.

@code{load("trigtools")} loads these functions.

Examples:

@enumerate

@item @w{ }
@c ===beg===
@c load(trigtools)$
@c sinh(x)=c2trig(sinh(x));
@c cosh(x)=c2trig(cosh(x));
@c tanh(x)=c2trig(tanh(x));
@c coth(x)=c2trig(coth(x));
@c ===end===
@example maxima
(%i1) load(trigtools)$
@group
(%i2) sinh(x)=c2trig(sinh(x));
(%o2)               sinh(x) = - %i sin(%i x)
@end group
@group
(%i3) cosh(x)=c2trig(cosh(x));
(%o3)                  cosh(x) = cos(%i x)
@end group
@group
(%i4) tanh(x)=c2trig(tanh(x));
(%o4)               tanh(x) = - %i tan(%i x)
@end group
@group
(%i5) coth(x)=c2trig(coth(x));
(%o5)                coth(x) = %i cot(%i x)
@end group
@end example

@item see @url{https://maxima.sourceforge.io/ext/list_archives/2013/msg03230.html}
@c ===beg===
@c load("trigtools")$
@c cos(p+q*%i);
@c trigexpand(%);
@c c2trig(%);
@c ===end===
@example maxima
(%i1) load("trigtools")$
@group
(%i2) cos(p+q*%i);
(%o2)                     cos(%i q + p)
@end group
@group
(%i3) trigexpand(%);
(%o3)          cos(p) cosh(q) - %i sin(p) sinh(q)
@end group
@group
(%i4) c2trig(%);
(%o4)                     cos(%i q + p)
@end group
@end example

@item @w{ }
@c ===beg===
@c load("trigtools")$
@c sin(a+b*%i);
@c trigexpand(%);
@c c2trig(%);
@c ===end===
@example maxima
(%i1) load("trigtools")$
@group
(%i2) sin(a+b*%i);
(%o2)                     sin(%i b + a)
@end group
@group
(%i3) trigexpand(%);
(%o3)          %i cos(a) sinh(b) + sin(a) cosh(b)
@end group
@group
(%i4) c2trig(%);
(%o4)                     sin(%i b + a)
@end group
@end example

@item @w{ }
@c ===beg===
@c load("trigtools")$
@c cos(a*%i+b*%i);
@c trigexpand(%);
@c c2trig(%);
@c ===end===
@example maxima
(%i1) load("trigtools")$
@group
(%i2) cos(a*%i+b*%i);
(%o2)                   cos(%i b + %i a)
@end group
@group
(%i3) trigexpand(%);
(%o3)           sinh(a) sinh(b) + cosh(a) cosh(b)
@end group
@group
(%i4) c2trig(%);
(%o4)                   cos(%i b + %i a)
@end group
@end example

@item @w{ }
@c ===beg===
@c load("trigtools")$
@c tan(a+%i*b);
@c trigexpand(%);
@c c2trig(%);
@c ===end===
@example maxima
(%i1) load("trigtools")$
@group
(%i2) tan(a+%i*b);
(%o2)                     tan(%i b + a)
@end group
@group
(%i3) trigexpand(%);
                       %i tanh(b) + tan(a)
(%o3)                 ---------------------
                      1 - %i tan(a) tanh(b)
@end group
@group
(%i4) c2trig(%);
(%o4)                     tan(%i b + a)
@end group
@end example

@item @w{ }

@c ===beg===
@c load("trigtools")$
@c cot(x+%i*y);
@c trigexpand(%);
@c c2trig(%);
@c ===end===
@example maxima
(%i1) load("trigtools")$
@group
(%i2) cot(x+%i*y);
(%o2)                     cot(%i y + x)
@end group
@group
(%i3) trigexpand(%);
                     - %i cot(x) coth(y) - 1
(%o3)                -----------------------
                       cot(x) - %i coth(y)
@end group
@group
(%i4) c2trig(%);
(%o4)                     cot(%i y + x)
@end group
@end example
@end enumerate

@opencatbox{Categories:}
@category{Trigonometric functions}
@category{Package trigtools}
@closecatbox

@end deffn

@node Convert to Hyperbolic Functions, Factor Sums of sin and cos Functions, Convert to Trigonometric Functions, Functions and Variables for trigtools
@subsection Convert to Hyperbolic Functions

@anchor{c2hyp}
@deffn {Function} c2hyp (@var{x})
The function c2hyp (convert to hyperbolic) convert expression with exp function
to expression with hyperbolic functions sinh, cosh.

@code{load("trigtools")} loads this function.

Examples:

@c ===beg===
@c load("trigtools")$
@c c2hyp(exp(x));
@c c2hyp(exp(x)+exp(x^2)+1);
@c c2hyp(exp(x)/(2*exp(y)-3*exp(z)));
@c ===end===
@example maxima
(%i1) load("trigtools")$
@group
(%i2) c2hyp(exp(x));
(%o2)                   sinh(x) + cosh(x)
@end group
@group
(%i3) c2hyp(exp(x)+exp(x^2)+1);
                 2          2
(%o3)      sinh(x ) + cosh(x ) + sinh(x) + cosh(x) + 1
@end group
@group
(%i4) c2hyp(exp(x)/(2*exp(y)-3*exp(z)));
                        sinh(x) + cosh(x)
(%o4)     ---------------------------------------------
          2 (sinh(y) + cosh(y)) - 3 (sinh(z) + cosh(z))
@end group
@end example

@opencatbox{Categories:}
@category{Trigonometric functions}
@category{Hyperbolic functions}
@category{Package trigtools}
@closecatbox
@end deffn

@node Factor Sums of sin and cos Functions, Solve Trigonometric Equations, Convert to Hyperbolic Functions, Functions and Variables for trigtools
@subsection Factor Sums of sin and cos Functions

@anchor{trigfactor}
@deffn {Function} trigfactor (@var{x})
The function trigfactor factors expressions of
form 
m4_mathdot(<<<\pm \sin x \pm \cos y>>>, <<<+-sin(x)+-cos(y)>>>)

@code{load("trigtools")} loads this function.

Examples:

@enumerate
@item @w{ }
@c ===beg===
@c load("trigtools")$
@c trigfactor(sin(x)+cos(x));
@c trigrat(%);
@c ===end===
@example maxima
(%i1) load("trigtools")$
@group
(%i2) trigfactor(sin(x)+cos(x));
                                      %pi
(%o2)                 sqrt(2) cos(x - ---)
                                       4
@end group
@group
(%i3) trigrat(%);
(%o3)                    sin(x) + cos(x)
@end group
@end example

@item @w{ }
@c ===beg===
@c load("trigtools")$
@c trigfactor(sin(x)+cos(y));
@c trigrat(%);
@c ===end===
@example maxima
(%i1) load("trigtools")$
@group
(%i2) trigfactor(sin(x)+cos(y));
                     y   x   %pi      y   x   %pi
(%o2)          2 cos(- - - + ---) cos(- + - - ---)
                     2   2    4       2   2    4
@end group
@group
(%i3) trigrat(%);
(%o3)                    cos(y) + sin(x)
@end group
@end example

@item @w{ }
@c ===beg===
@c load("trigtools")$
@c trigfactor(sin(x)-cos(3*y));
@c trigrat(%);
@c ===end===
@example maxima
(%i1) load("trigtools")$
@group
(%i2) trigfactor(sin(x)-cos(3*y));
                   3 y   x   %pi      3 y   x   %pi
(%o2)        2 sin(--- - - + ---) sin(--- + - - ---)
                    2    2    4        2    2    4
@end group
@group
(%i3) trigrat(%);
(%o3)                   sin(x) - cos(3 y)
@end group
@end example

@item @w{ }
@c ===beg===
@c load("trigtools")$
@c trigfactor(-sin(5*x)-cos(3*y));
@c trigrat(%);
@c ===end===
@example maxima
(%i1) load("trigtools")$
@group
(%i2) trigfactor(-sin(5*x)-cos(3*y));
                  3 y   5 x   %pi      3 y   5 x   %pi
(%o2)     - 2 cos(--- - --- + ---) cos(--- + --- - ---)
                   2     2     4        2     2     4
@end group
@group
(%i3) trigrat(%);
(%o3)                 - cos(3 y) - sin(5 x)
@end group
@end example

@item @w{ }
@c ===beg===
@c load("trigtools")$
@c sin(alpha)+sin(beta)=trigfactor(sin(alpha)+sin(beta));
@c trigrat(%);
@c ===end===
@example maxima
(%i1) load("trigtools")$
@group
(%i2) sin(alpha)+sin(beta)=trigfactor(sin(alpha)+sin(beta));
                                     beta   alpha
(%o2) sin(beta) + sin(alpha) = 2 cos(---- - -----)
                                      2       2
                                                    beta   alpha
                                                sin(---- + -----)
                                                     2       2
@end group
@group
(%i3) trigrat(%);
(%o3)    sin(beta) + sin(alpha) = sin(beta) + sin(alpha)
@end group
@end example

@item @w{ }
@c ===beg===
@c load("trigtools")$
@c sin(alpha)-sin(beta)=trigfactor(sin(alpha)-sin(beta));
@c ===end===
@example maxima
(%i1) load("trigtools")$
@group
(%i2) sin(alpha)-sin(beta)=trigfactor(sin(alpha)-sin(beta));
                                       beta   alpha
(%o2) sin(alpha) - sin(beta) = - 2 sin(---- - -----)
                                        2       2
                                                    beta   alpha
                                                cos(---- + -----)
                                                     2       2
@end group
@end example

@item @w{ }
@c ===beg===
@c load("trigtools")$
@c cos(alpha)+cos(beta)=trigfactor(cos(alpha)+cos(beta));
@c ===end===
@example maxima
(%i1) load("trigtools")$
@group
(%i2) cos(alpha)+cos(beta)=trigfactor(cos(alpha)+cos(beta));
                                     beta   alpha
(%o2) cos(beta) + cos(alpha) = 2 cos(---- - -----)
                                      2       2
                                                    beta   alpha
                                                cos(---- + -----)
                                                     2       2
@end group
@end example

@item @w{ }
@c ===beg===
@c load("trigtools")$
@c cos(alpha)-cos(beta)=trigfactor(cos(alpha)-cos(beta));
@c ===end===
@example maxima
(%i1) load("trigtools")$
@group
(%i2) cos(alpha)-cos(beta)=trigfactor(cos(alpha)-cos(beta));
                                     beta   alpha
(%o2) cos(alpha) - cos(beta) = 2 sin(---- - -----)
                                      2       2
                                                    beta   alpha
                                                sin(---- + -----)
                                                     2       2
@end group
@end example

@item @w{ }
@c ===beg===
@c load("trigtools")$
@c trigfactor(3*sin(x)+7*cos(x));
@c c2sin(%);
@c trigexpand(%),expand;
@c ===end===
@example maxima
(%i1) load("trigtools")$
@group
(%i2) trigfactor(3*sin(x)+7*cos(x));
(%o2)                  3 sin(x) + 7 cos(x)
@end group
@group
(%i3) c2sin(%);
                                          7
(%o3)               sqrt(58) sin(x + atan(-))
                                          3
@end group
@group
(%i4) trigexpand(%),expand;
(%o4)                  3 sin(x) + 7 cos(x)
@end group
@end example

@item @w{ }
@c ===beg===
@c load("trigtools")$
@c trigfactor(sin(2*x));
@c trigexpand(%);
@c ===end===
@example maxima
(%i1) load("trigtools")$
@group
(%i2) trigfactor(sin(2*x));
(%o2)                       sin(2 x)
@end group
@group
(%i3) trigexpand(%);
(%o3)                    2 cos(x) sin(x)
@end group
@end example
@end enumerate

@opencatbox{Categories:}
@category{Trigonometric functions}
@category{Package trigtools}
@closecatbox
@end deffn

@node Solve Trigonometric Equations, Evaluation of Trigonometric Functions, Factor Sums of sin and cos Functions, Functions and Variables for trigtools
@subsection Solve Trigonometric Equations

@anchor{trigsolve}
@deffn {Function} trigsolve (@var{x})
The function trigsolve find solutions of trigonometric equation from
interval 
m4_mathdot(<<<[a,b)>>>, <<<[a, b)>>>)

@code{load("trigtools")} loads this function.


Examples:
@enumerate
@item @w{ }
@c ===beg===
@c eq:eq:3*sin(x)+4*cos(x)=2;
@c plot2d([3*sin(x)+4*cos(x),2],[x,-%pi,%pi]);
@c ===end===
@example maxima
@group
(%i1) eq:eq:3*sin(x)+4*cos(x)=2;
(%o1)                3 sin(x) + 4 cos(x) = 2
@end group
@group
(%i2) plot2d([3*sin(x)+4*cos(x),2],[x,-%pi,%pi]);
(%o2)                         false
@end group
@end example

@center @image{figures/trigtools-2,5in,,plot2}

@c ===beg===
@c load("trigtools")$
@c eq:eq:3*sin(x)+4*cos(x)=2$
@c sol:trigsolve(eq,-%pi,%pi);
@c float(%), numer;
@c ===end===
@example maxima
(%i1) load("trigtools")$
(%i2) eq:eq:3*sin(x)+4*cos(x)=2$
@group
(%i3) sol:trigsolve(eq,-%pi,%pi);
            2 sqrt(21)   12              2 sqrt(21)   12
(%o3) @{atan(---------- - --), %pi - atan(---------- + --)@}
                5        5                   5        5
@end group
@group
(%i4) float(%), numer;
(%o4)      @{- 0.5157783719341241, 1.8027805895206928@}
@end group
@end example

Answ. : 
m4_math(<<<x = \tan^{-1}\left({2\sqrt{21}\over 5} - {12\over
5}\right) + 2\pi k>>>, <<<x = atan((2*sqrt(21))/5-12/5)+2*%pi*k>>>)
;
m4_mathcomma(<<<x = \pi - \tan^{-1}\left({2\sqrt{21}\over 5} +
{12\over 5}\right) + 2\pi k>>>,
<<<x=%pi-atan((2*sqrt(21))/5+12/5)+2*%pi*k>>>) 
@math{k} -- any integer.

@item @w{ }
@c ===beg===
@c load("trigtools")$
@c eq:cos(3*x)-sin(x)=sqrt(3)*(cos(x)-sin(3*x));
@c plot2d([lhs(eq)-rhs(eq)], [x,0,2*%pi])$
@c ===end===
@example maxima
(%i1) load("trigtools")$
@group
(%i2) eq:cos(3*x)-sin(x)=sqrt(3)*(cos(x)-sin(3*x));
(%o2)    cos(3 x) - sin(x) = sqrt(3) (cos(x) - sin(3 x))
@end group
(%i3) plot2d([lhs(eq)-rhs(eq)], [x,0,2*%pi])$
@end example

@center @image{figures/trigtools-3,5in,,plot3}

We have 6 solutions from [0, 2*pi].
@c ===beg===
@c load("trigtools")$
@c eq:cos(3*x)-sin(x)=sqrt(3)*(cos(x)-sin(3*x))$
@c plot2d([lhs(eq)-rhs(eq)], [x,0.2,0.5])$
@c ===end===
@example maxima
(%i1) load("trigtools")$
(%i2) eq:cos(3*x)-sin(x)=sqrt(3)*(cos(x)-sin(3*x))$
(%i3) plot2d([lhs(eq)-rhs(eq)], [x,0.2,0.5])$
@end example

@center @image{figures/trigtools-4,5in,,plot4}

@c ===beg===
@c load("trigtools")$
@c load("trigtools")$
@c eq:cos(3*x)-sin(x)=sqrt(3)*(cos(x)-sin(3*x))$
@c plot2d([lhs(eq)-rhs(eq)], [x,3.3,3.6])$
@c ===end===
@example maxima
(%i1) load("trigtools")$
(%i2) load("trigtools")$
(%i3) eq:cos(3*x)-sin(x)=sqrt(3)*(cos(x)-sin(3*x))$
(%i4) plot2d([lhs(eq)-rhs(eq)], [x,3.3,3.6])$
@end example

@center @image{figures/trigtools-5,5in,,plot4}

@c ===beg===
@c load("trigtools")$
@c eq:cos(3*x)-sin(x)=sqrt(3)*(cos(x)-sin(3*x))$
@c trigfactor(lhs(eq))=map(trigfactor,rhs(eq));
@c factor(lhs(%)-rhs(%));
@c ===end===
@example maxima
(%i1) load("trigtools")$
(%i2) eq:cos(3*x)-sin(x)=sqrt(3)*(cos(x)-sin(3*x))$
@group
(%i3) trigfactor(lhs(eq))=map(trigfactor,rhs(eq));
                  %pi            %pi
(%o3) - 2 sin(x + ---) sin(2 x - ---) = 
                   4              4
                                              %pi            %pi
                            2 sqrt(3) sin(x - ---) sin(2 x - ---)
                                               4              4
@end group
@group
(%i4) factor(lhs(%)-rhs(%));
               4 x + %pi                4 x - %pi
(%o4) - 2 (sin(---------) + sqrt(3) sin(---------))
                   4                        4
                                                       8 x - %pi
                                                   sin(---------)
                                                           4
@end group
@end example

Equation is equivalent to
@c ===beg===
@c load("trigtools")$
@c eq:cos(3*x)-sin(x)=sqrt(3)*(cos(x)-sin(3*x))$
@c trigfactor(lhs(eq))=map(trigfactor,rhs(eq));
@c L:factor(rhs(%)-lhs(%));
@c eq1:part(L,2)=0;
@c eq2:part(L,3)=0;
@c S1:trigsolve(eq1,0,2*%pi);
@c S2:trigsolve(eq2,0,2*%pi);
@c S:listify(union(S1,S2));
@c float(%), numer;
@c ===end===
@example maxima
(%i1) load("trigtools")$
(%i2) eq:cos(3*x)-sin(x)=sqrt(3)*(cos(x)-sin(3*x))$
@group
(%i3) trigfactor(lhs(eq))=map(trigfactor,rhs(eq));
                  %pi            %pi
(%o3) - 2 sin(x + ---) sin(2 x - ---) = 
                   4              4
                                              %pi            %pi
                            2 sqrt(3) sin(x - ---) sin(2 x - ---)
                                               4              4
@end group
@group
(%i4) L:factor(rhs(%)-lhs(%));
             4 x + %pi                4 x - %pi       8 x - %pi
(%o4) 2 (sin(---------) + sqrt(3) sin(---------)) sin(---------)
                 4                        4               4
@end group
@group
(%i5) eq1:part(L,2)=0;
               4 x + %pi                4 x - %pi
(%o5)      sin(---------) + sqrt(3) sin(---------) = 0
                   4                        4
@end group
@group
(%i6) eq2:part(L,3)=0;
                           8 x - %pi
(%o6)                  sin(---------) = 0
                               4
@end group
@group
(%i7) S1:trigsolve(eq1,0,2*%pi);
                           %pi  13 %pi
(%o7)                     @{---, ------@}
                           12     12
@end group
@group
(%i8) S2:trigsolve(eq2,0,2*%pi);
                    %pi  5 %pi  9 %pi  13 %pi
(%o8)              @{---, -----, -----, ------@}
                     8     8      8      8
@end group
@group
(%i9) S:listify(union(S1,S2));
             %pi  %pi  5 %pi  13 %pi  9 %pi  13 %pi
(%o9)       [---, ---, -----, ------, -----, ------]
             12    8     8      12      8      8
@end group
@group
(%i10) float(%), numer;
(%o10) [0.2617993877991494, 0.39269908169872414, 
1.9634954084936207, 3.4033920413889422, 3.5342917352885173, 
5.105088062083414]
@end group
@end example

Answer: 
m4_mathcomma(<<<x = a + 2\pi k>>>, <<<x = a+2*%pi*k>>>)
where @math{a} any from @math{S}, @math{k} any integer.

@item @w{ }
@c ===beg===
@c load("trigtools")$
@c eq:8*cos(x)*cos(4*x)*cos(5*x)-1=0;
@c trigrat(%);
@c ===end===
@example maxima
(%i1) load("trigtools")$
@group
(%i2) eq:8*cos(x)*cos(4*x)*cos(5*x)-1=0;
(%o2)          8 cos(x) cos(4 x) cos(5 x) - 1 = 0
@end group
@group
(%i3) trigrat(%);
(%o3)     2 cos(10 x) + 2 cos(8 x) + 2 cos(2 x) + 1 = 0
@end group
@end example

Left side is periodic with period 
m4_mathdot(<<<T=\pi>>>, <<<T=%pi>>>)

We have 10 solutions from [0, pi].
@c ===beg===
@c load("trigtools")$
@c eq:8*cos(x)*cos(4*x)*cos(5*x)-1=0$
@c plot2d([lhs(eq),rhs(eq)],[x,0,%pi]);
@c ===end===
@example maxima
(%i1) load("trigtools")$
(%i2) eq:8*cos(x)*cos(4*x)*cos(5*x)-1=0$
@group
(%i3) plot2d([lhs(eq),rhs(eq)],[x,0,%pi]);
(%o3)                         false
@end group
@end example

@center @image{figures/trigtools-6,5in,,plot6}

@c ===beg===
@c load("trigtools")$
@c eq:8*cos(x)*cos(4*x)*cos(5*x)-1=0$
@c x4:find_root(eq, x, 1.3, 1.32);
@c x5:find_root(eq, x, 1.32, 1.35);
@c plot2d([lhs(eq),0], [x,1.3,1.35], [gnuplot_preamble, "set grid;"]);
@c ===end===
@example maxima
(%i1) load("trigtools")$
(%i2) eq:8*cos(x)*cos(4*x)*cos(5*x)-1=0$
@group
(%i3) x4:find_root(eq, x, 1.3, 1.32);
(%o3)                  1.3089969389957472
@end group
@group
(%i4) x5:find_root(eq, x, 1.32, 1.35);
(%o4)                  1.3463968515384828
@end group
@group
(%i5) plot2d([lhs(eq),0], [x,1.3,1.35], [gnuplot_preamble, "set grid;"]);
(%o5)                         false
@end group
@end example

@center @image{figures/trigtools-7,5in,,plot7}

Equation we multiply by 
m4_mathpunc(:, <<<2\sin x\cos 2x>>>, <<<2*sin(x)*cos(2*x)>>>)


@c ===beg===
@c load("trigtools")$
@c eq:8*cos(x)*cos(4*x)*cos(5*x)-1=0$
@c eq*2*sin(x)*cos(2*x);
@c eq1:trigreduce(%),expand;
@c trigfactor(lhs(eq1))=0;
@c S1:trigsolve(cos(6*x),0,%pi);
@c S2:trigsolve(sin(7*x),0,%pi);
@c ===end===
@example maxima
(%i1) load("trigtools")$
(%i2) eq:8*cos(x)*cos(4*x)*cos(5*x)-1=0$
@group
(%i3) eq*2*sin(x)*cos(2*x);
(%o3) 2 sin(x) cos(2 x) (8 cos(x) cos(4 x) cos(5 x) - 1) = 0
@end group
@group
(%i4) eq1:trigreduce(%),expand;
(%o4)                sin(13 x) + sin(x) = 0
@end group
@group
(%i5) trigfactor(lhs(eq1))=0;
(%o5)                2 cos(6 x) sin(7 x) = 0
@end group
@group
(%i6) S1:trigsolve(cos(6*x),0,%pi);
              %pi  %pi  5 %pi  7 %pi  3 %pi  11 %pi
(%o6)        @{---, ---, -----, -----, -----, ------@}
              12    4    12     12      4      12
@end group
@group
(%i7) S2:trigsolve(sin(7*x),0,%pi);
               %pi  2 %pi  3 %pi  4 %pi  5 %pi  6 %pi
(%o7)      @{0, ---, -----, -----, -----, -----, -----@}
                7     7      7      7      7      7
@end group
@end example

We remove solutions of 
m4_math(<<<\sin x = 0>>>, <<<sin(x)=0>>>) 
and
m4_mathdot(<<<\cos 2x = 0>>>, <<<cos(2*x) = 0>>>)

@c ===beg===
@c load("trigtools")$
@c S1:trigsolve(cos(6*x),0,%pi)$
@c S2:trigsolve(sin(7*x),0,%pi)$
@c S3:trigsolve(sin(x),0,%pi);
@c S4:trigsolve(cos(2*x),0,%pi);
@c ===end===
@example maxima
(%i1) load("trigtools")$
(%i2) S1:trigsolve(cos(6*x),0,%pi)$
(%i3) S2:trigsolve(sin(7*x),0,%pi)$
@group
(%i4) S3:trigsolve(sin(x),0,%pi);
(%o4)                          @{0@}
@end group
@group
(%i5) S4:trigsolve(cos(2*x),0,%pi);
                           %pi  3 %pi
(%o5)                     @{---, -----@}
                            4     4
@end group
@end example

We find 10 solutions from 
m4_mathpunc(:,<<<[0, \pi]>>>,<<<[0, %pi]>>>)

@c ===beg===
@c load("trigtools")$
@c S1:trigsolve(cos(6*x),0,%pi)$
@c S2:trigsolve(sin(7*x),0,%pi)$
@c S3:trigsolve(sin(x),0,%pi)$
@c S4:trigsolve(cos(2*x),0,%pi)$
@c union(S1,S2)$ setdifference(%,S3)$ setdifference(%,S4);
@c S:listify(%);
@c length(S);
@c float(S), numer;
@c ===end===
@example maxima
(%i1) load("trigtools")$
(%i2) S1:trigsolve(cos(6*x),0,%pi)$
(%i3) S2:trigsolve(sin(7*x),0,%pi)$
(%i4) S3:trigsolve(sin(x),0,%pi)$
(%i5) S4:trigsolve(cos(2*x),0,%pi)$
@group
(%i6) union(S1,S2)$ setdifference(%,S3)$ setdifference(%,S4);
       %pi  %pi  2 %pi  5 %pi  3 %pi  4 %pi  7 %pi  5 %pi
(%o8) @{---, ---, -----, -----, -----, -----, -----, -----, 
       12    7     7     12      7      7     12      7
                                                   6 %pi  11 %pi
                                                   -----, ------@}
                                                     7      12
@end group
@group
(%i9) S:listify(%);
       %pi  %pi  2 %pi  5 %pi  3 %pi  4 %pi  7 %pi  5 %pi
(%o9) [---, ---, -----, -----, -----, -----, -----, -----, 
       12    7     7     12      7      7     12      7
                                                   6 %pi  11 %pi
                                                   -----, ------]
                                                     7      12
@end group
@group
(%i10) length(S);
(%o10)                         10
@end group
@group
(%i11) float(S), numer;
(%o11) [0.2617993877991494, 0.4487989505128276, 
0.8975979010256552, 1.3089969389957472, 1.3463968515384828, 
1.7951958020513104, 1.8325957145940461, 2.243994752564138, 
2.6927937030769655, 2.8797932657906435]
@end group
@end example
Answer: 
m4_mathcomma(<<<x = a + 2\pi k>>>, <<<x = a+2*%pi*k>>>)
where @math{a} any from @math{S}, @math{k} any integer.

@end enumerate

@opencatbox{Categories:}
@category{Trigonometric functions}
@category{Package trigtools}
@closecatbox
@end deffn

@node Evaluation of Trigonometric Functions, Contract atan Functions, Solve Trigonometric Equations, Functions and Variables for trigtools
@subsection Evaluation of Trigonometric Functions

@anchor{trigvalue}
@deffn {Function} trigvalue (@var{x})
The function trigvalue compute values of 
m4_mathcomma(<<<\sin
{m\pi\over n}>>>, <<<sin(m*%pi/n)>>>)
m4_mathcomma(<<<\cos
{m\pi\over n}>>>, <<<cos(m*%pi/n)>>>)
m4_mathcomma(<<<\tan
{m\pi\over n}>>>, <<<tan(m*%pi/n)>>>)
and 
m4_math(<<<\cot
{m\pi\over n}>>>, <<<cot(m*%pi/n)>>>) 
in radicals.

@code{trigvalue} is essentially an internal function.
Use function @mref{trigeval} in preference.

@code{load("trigtools")} loads this function.

@end deffn

@anchor{trigeval}
@deffn {Function} trigeval (@var{x})
The function trigeval compute values of expressions with 
m4_mathcomma(<<<\sin
{m\pi\over n}>>>, <<<sin(m*%pi/n)>>>)
m4_mathcomma(<<<\cos
{m\pi\over n}>>>, <<<cos(m*%pi/n)>>>)
m4_mathcomma(<<<\tan
{m\pi\over n}>>>, <<<tan(m*%pi/n)>>>) 
and 
m4_math(<<<\cot
{m\pi\over n}>>>, <<<cot(m*%pi/n)>>>) 
in radicals.
@end deffn

@code{load("trigtools")} loads this function.

Examples:
@enumerate
@item Values of trigonometric functions
@c ===beg===
@c load("trigtools")$
@c trigvalue(sin(%pi/10));
@c trigvalue(cos(%pi/10));
@c trigvalue(tan(%pi/10));
@c float(%), numer;
@c float(tan(%pi/10)), numer;
@c trigvalue(cot(%pi/10));
@c float(%), numer;
@c float(cot(%pi/10)), numer;
@c trigvalue(sin(%pi/32));
@c trigvalue(cos(%pi/32));
@c trigvalue(cos(%pi/256));
@c trigvalue(cos(%pi/60));
@c trigvalue(sin(%pi/60));
@c trigvalue(sin(%pi/18));
@c trigvalue(sin(%pi/20));
@c ===end===
@example maxima
(%i1) load("trigtools")$
(%i2) load(trigtools)$
@group
(%i3) trigvalue(sin(%pi/10));
                           sqrt(5) - 1
(%o3)                      -----------
                                4
@end group
@group
(%i4) trigvalue(cos(%pi/10));
                        sqrt(sqrt(5) + 5)
(%o4)                   -----------------
                               3/2
                              2
@end group
@group
(%i5) trigvalue(tan(%pi/10));
                       sqrt(5 - 2 sqrt(5))
(%o5)                  -------------------
                             sqrt(5)
@end group
@group
(%i6) float(%), numer;
(%o6)                  0.3249196962329063
@end group
@group
(%i7) float(tan(%pi/10)), numer;
(%o7)                  0.3249196962329063
@end group
@group
(%i8) trigvalue(cot(%pi/10));
(%o8)                  sqrt(2 sqrt(5) + 5)
@end group
@group
(%i9) float(%), numer;
(%o9)                  3.0776835371752536
@end group
@group
(%i10) float(cot(%pi/10)), numer;
(%o10)                  3.077683537175254
@end group
@group
(%i11) trigvalue(sin(%pi/32));
              sqrt(2 - sqrt(sqrt(sqrt(2) + 2) + 2))
(%o11)        -------------------------------------
                                2
@end group
@group
(%i12) trigvalue(cos(%pi/32));
              sqrt(sqrt(sqrt(sqrt(2) + 2) + 2) + 2)
(%o12)        -------------------------------------
                                2
@end group
@group
(%i13) trigvalue(cos(%pi/256));
(%o13) sqrt(sqrt(sqrt(sqrt(sqrt(sqrt(sqrt(2) + 2) + 2) + 2) + 2)
                                                      + 2) + 2)/2
@end group
@group
(%i14) trigvalue(cos(%pi/60));
(%o14) 
  sqrt(sqrt(sqrt(2) sqrt(3) sqrt(sqrt(5) + 5) + sqrt(5) + 7) + 4)
  ---------------------------------------------------------------
                                3/2
                               2
@end group
@group
(%i15) trigvalue(sin(%pi/60));
(%o15) 
  sqrt(4 - sqrt(sqrt(2) sqrt(3) sqrt(sqrt(5) + 5) + sqrt(5) + 7))
  ---------------------------------------------------------------
                                3/2
                               2
@end group
@group
(%i16) trigvalue(sin(%pi/18));
                                %pi
(%o16)                      sin(---)
                                18
@end group
@group
(%i17) trigvalue(sin(%pi/20));
               sqrt(4 - sqrt(2) sqrt(sqrt(5) + 5))
(%o17)         -----------------------------------
                               3/2
                              2
@end group
@end example

@item ode example
@c ===beg===
@c load("trigtools")$
@c load(odes)$
@c eq:'diff(y,x,5)+2*y=0;
@c odeL(eq,y,x);
@c sol:trigeval(%);
@c subst(sol,eq)$
@c ev(%, nouns)$
@c radcan(%);
@c ===end===
@example maxima
(%i1) load("trigtools")$
(%i2) load(odes)$
@group
(%i3) eq:'diff(y,x,5)+2*y=0;
                           5
                          d y
(%o3)                     --- + 2 y = 0
                            5
                          dx
@end group
@group
(%i4) odeL(eq,y,x);
               1/5     4 %pi
            - 2    cos(-----) x
                         5              1/5     4 %pi
(%o4) y = %e                    C5 sin(2    sin(-----) x)
                                                  5
        1/5     4 %pi
     - 2    cos(-----) x
                  5              1/5     4 %pi
 + %e                    C4 cos(2    sin(-----) x)
                                           5
        1/5     2 %pi
     - 2    cos(-----) x
                  5              1/5     2 %pi
 + %e                    C3 sin(2    sin(-----) x)
                                           5
        1/5     2 %pi
     - 2    cos(-----) x
                  5              1/5     2 %pi
 + %e                    C2 cos(2    sin(-----) x)
                                           5
        1/5
     - 2    x
 + %e         C1
@end group
@group
(%i5) sol:trigeval(%);
              (sqrt(5) - 1) x
            - ---------------
                    9/5
                   2                 sqrt(sqrt(5) + 5) x
(%o5) y = %e                  C3 sin(-------------------)
                                            13/10
                                           2
       (sqrt(5) - 1) x
     - ---------------
             9/5
            2                 sqrt(sqrt(5) + 5) x
 + %e                  C2 cos(-------------------)
                                     13/10
                                    2
     (sqrt(5) + 1) x
     ---------------
           9/5
          2                 sqrt(5 - sqrt(5)) x
 + %e                C5 sin(-------------------)
                                   13/10
                                  2
     (sqrt(5) + 1) x
     ---------------
           9/5                                          1/5
          2                 sqrt(5 - sqrt(5)) x      - 2    x
 + %e                C4 cos(-------------------) + %e         C1
                                   13/10
                                  2
@end group
(%i6) subst(sol,eq)$
(%i7) ev(%, nouns)$
@group
(%i8) radcan(%);
(%o8)                         0 = 0
@end group
@end example

@item n-th root of complex number

Example. Find the 4-th roots of %i
@c ===beg===
@c load("trigtools")$
@c solve(x^4=%i,x);
@c rectform(%);
@c trigeval(%);
@c ===end===
@example maxima
(%i1) load("trigtools")$
@group
(%i2) solve(x^4=%i,x);
                1/8                1/8             1/8
(%o2) [x = (- 1)    %i, x = - (- 1)   , x = - (- 1)    %i, 
                                                             1/8
                                                    x = (- 1)   ]
@end group
@group
(%i3) rectform(%);
                  %pi        %pi                %pi        %pi
(%o3) [x = %i cos(---) - sin(---), x = - %i sin(---) - cos(---), 
                   8          8                  8          8
                  %pi           %pi              %pi        %pi
          x = sin(---) - %i cos(---), x = %i sin(---) + cos(---)]
                   8             8                8          8
@end group
@group
(%i4) trigeval(%);
           sqrt(sqrt(2) + 2) %i   sqrt(2 - sqrt(2))
(%o4) [x = -------------------- - -----------------, 
                    2                     2
      sqrt(2 - sqrt(2)) %i   sqrt(sqrt(2) + 2)
x = - -------------------- - -----------------, 
               2                     2
    sqrt(2 - sqrt(2))   sqrt(sqrt(2) + 2) %i
x = ----------------- - --------------------, 
            2                    2
    sqrt(2 - sqrt(2)) %i   sqrt(sqrt(2) + 2)
x = -------------------- + -----------------]
             2                     2
@end group
@end example
@end enumerate

@opencatbox{Categories:}
@category{Trigonometric functions}
@category{Package trigtools}
@closecatbox

@node Contract atan Functions,  , Evaluation of Trigonometric Functions, Functions and Variables for trigtools
@subsection Contract atan Functions

@anchor{atan_contract}
@deffn {Function} atan_contract (@var{r})
The function atan_contract(r) contracts atan functions. We
assume: 
m4_mathdot(<<<|r| < {\pi\over 2}>>>, <<<abs(r)<%pi/2>>>)

@code{load("trigtools")} loads this function.


Examples:

@enumerate
@item @w{ }
@c ===beg===
@c load("trigtools")$
@c atan_contract(atan(x)+atan(y));
@c assume(abs(atan(x)+atan(y))<%pi/2)$
@c atan(x)+atan(y)=atan_contract(atan(x)+atan(y));
@c ===end===
@example maxima
(%i1) load("trigtools")$
@group
(%i2) atan_contract(atan(x)+atan(y));
(%o2)                   atan(y) + atan(x)
@end group
(%i3) assume(abs(atan(x)+atan(y))<%pi/2)$
@group
(%i4) atan(x)+atan(y)=atan_contract(atan(x)+atan(y));
                                          y + x
(%o4)           atan(y) + atan(x) = atan(-------)
                                         1 - x y
@end group
@end example

@item @w{ }
@c ===beg===
@c load("trigtools")$
@c atan(1/3)+atan(1/5)+atan(1/7)+atan(1/8)$ %=atan_contract(%);
@c ===end===
@example maxima
(%i1) load("trigtools")$
@group
(%i2) atan(1/3)+atan(1/5)+atan(1/7)+atan(1/8)$ %=atan_contract(%);
                1         1         1         1    %pi
(%o3)      atan(-) + atan(-) + atan(-) + atan(-) = ---
                3         5         7         8     4
@end group
@end example

@item Machin's formulae
@c ===beg===
@c load("trigtools")$
@c 4*atan(1/5)-atan(1/239)=atan_contract(4*atan(1/5)-atan(1/239));
@c ===end===
@example maxima
(%i1) load("trigtools")$
@group
(%i2) 4*atan(1/5)-atan(1/239)=atan_contract(4*atan(1/5)-atan(1/239));
                          1          1     %pi
(%o2)              4 atan(-) - atan(---) = ---
                          5         239     4
@end group
@end example

@item see @url{https://en.wikipedia.org/wiki/Machin-like_formula}
@c ===beg===
@c load("trigtools")$
@c 12*atan(1/49)+32*atan(1/57)-5*atan(1/239)+12*atan(1/110443)$
@c %=atan_contract(%);
@c ===end===
@example maxima
(%i1) load("trigtools")$
(%i2) 12*atan(1/49)+32*atan(1/57)-5*atan(1/239)+12*atan(1/110443)$
@group
(%i3) %=atan_contract(%);
              1             1             1
(%o3) 12 atan(--) + 32 atan(--) - 5 atan(---)
              49            57           239
                                                      1       %pi
                                          + 12 atan(------) = ---
                                                    110443     4
@end group
@end example
@end enumerate

@opencatbox{Categories:}
@category{Trigonometric functions}
@category{Package trigtools}
@closecatbox

@end deffn

@node References,  , Functions and Variables for trigtools, Package trigtools
@section References

@enumerate
@item @url{https://maxima.sourceforge.io}
@end enumerate


